import React, { Children } from 'react'

const Card= ({Children}) => {
  return (
    <div className='bg-white shadow-md rounded-lg p-4 m-2'>
      {Children}
    </div>
  );
};

export default Card;
