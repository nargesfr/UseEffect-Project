import { useEffect, useState } from "react";
import Card from "./Card";

function App() {
  const [product, setProduct] = useState([]);

  useEffect(() => {
    fetch('https://fakestoreapi.com/products')
      .then(res => res.json())
      .then((result) => {
        console.log(result);
        setProduct(result);
      });
  }, []);

  return (
    <div className="flex items-center justify-center h-[100vh] w-full">
      {product.map((item) => (
        <Card key={item.id}>
          <div>
            <h1>{item.title}</h1>
            <p>{item.price}</p>
            <img src={item.image} alt={item.title} />
            <span>{item?.rating?.rate}</span>
          </div>
        </Card>
      ))}
    </div>
  );
}

export default App;